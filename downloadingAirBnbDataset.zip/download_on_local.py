import os
import shutil

# 원격 서버의 이미지 폴더 경로
remote_path = '/home/elicer/bnb-dataset/data/images'

# 로컬 컴퓨터의 대상 폴더 경로
local_path = '/path/to/local/folder'

# 원격 폴더의 모든 파일을 순회하며 로컬로 복사
for filename in os.listdir(remote_path):
    file_path = os.path.join(remote_path, filename)
    if os.path.isfile(file_path):
        shutil.copy(file_path, local_path)
