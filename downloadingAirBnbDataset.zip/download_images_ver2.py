import os
import pandas as pd
import requests

def download_images_from_csv(csv_file, output_dir):
    df = pd.read_csv(csv_file, header=None, names=['url', 'filename'])

    os.makedirs(output_dir, exist_ok=True)

    for index, row in df.iterrows():
        url = row['url']
        filename = row['filename']
        print(filename)

        response = requests.get(url)
        if response.status_code == 200:
            with open(os.path.join(output_dir, filename), 'wb') as f:
                f.write(response.content)
                print(f"다운로드 완료: {filename}")
        else:
            print(f"다운로드 실패: {filename}")

if __name__ == "__main__":
    csv_file = "/home/elicer/bnb-dataset/data/cache-download-images/1-30.csv"
    output_dir = "/home/elicer/bnb-dataset/data/images/1"
    download_images_from_csv(csv_file, output_dir)
