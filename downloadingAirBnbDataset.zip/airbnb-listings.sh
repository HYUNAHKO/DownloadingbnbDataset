wget https://public.opendatasoft.com/explore/dataset/airbnb-listings/download/\?format\=csv\&timezone\=Europe/Berlin\&lang\=en\&use_labels_for_header\=true\&csv_separator\=%3B
